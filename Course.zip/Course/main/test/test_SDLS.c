#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_thread.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "..\biblio\SDLS.h"
#include "..\biblio\net.h"
#include "..\biblio\image.h"



Uint32 my_callbackfunc(Uint32 interval, void *param)
{
    SDL_Event event;
    SDL_UserEvent userevent;

    userevent.type = SDL_USEREVENT;
    userevent.code = 0;
    userevent.data1 = NULL;
    userevent.data2 = NULL;

    event.type = SDL_USEREVENT;
    event.user = userevent;

    SDL_PushEvent(&event);
    return(interval);
}


int main(int argc, char ** argv)
{
int quit= false;
int flag=0;

SDLS_init("test");
        Uint32 delay = 60;
        SDL_TimerID my_timer = SDL_AddTimer(delay,my_callbackfunc,NULL);

        fn_conf_image ();
        fn_charger_image();
        fn_decoupage();


while(!quit)
    {
        SDL_Event event;

        SDL_WaitEvent(&event);

        switch (event.type)
        {
        case SDL_QUIT :
            quit = true;
            break;

        case SDL_USEREVENT :
            if(event.user.code==0)
             SDLS_eraseWithBackgroundColor(255,255,255);
             fn_affiche_bonhomme(flag);


             //if(Random==0)
                fn_haie();
             //else if(Random==1)
                fn_plafond();



             break;
        case SDL_KEYDOWN : case SDL_KEYUP:
                if(event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_UP &&  event.key.keysym.sym != SDLK_DOWN )
                {
                    flag=1; //SAUT
                }

             if(event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_DOWN &&  event.key.keysym.sym != SDLK_UP)
                {
                    flag=2; //ACCROUPI
                }

            if(event.type == SDL_KEYUP && event.key.keysym.sym == SDLK_UP && event.key.keysym.sym != SDLK_DOWN )
                {
                    flag=0; //MARCHE
                }
            if(event.type == SDL_KEYUP && event.key.keysym.sym == SDLK_DOWN && event.key.keysym.sym != SDLK_UP)
                {
                    flag=0; //MARCHE
                }



        }







        SDLS_displayAll();
    }
SDL_RemoveTimer( my_timer);
SDLS_cleanup();
    return 0;
}

