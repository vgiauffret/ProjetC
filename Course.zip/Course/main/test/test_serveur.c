#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_thread.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "..\biblio\SDLS.h"
#include "..\biblio\net.h"
#include "..\biblio\image.h"



int gQuit=false;



int threadReceiver( void* data )
{
    char msg[30];
    printf( "Running thread with value = %d\n", (int)data );
    while( gQuit == false )
    {
        //on renvoie la donn�e lue

        if(net_CheckForData(msg)>0)
        {
            puts(msg);
            SDL_Event event;
            SDL_UserEvent userevent;

            /* In this example, our callback pushes an SDL_USEREVENT event
            into the queue, and causes our callback to be called again at the
            same interval: */

            userevent.type = SDL_USEREVENT;
            userevent.code = 1;
            userevent.data1 = msg;
            userevent.data2 = NULL;

            event.type = SDL_USEREVENT;
            event.user = userevent;

            SDL_PushEvent(&event);

        }
        SDL_Delay(50);
    }

}


Uint32 my_callbackfunc(Uint32 interval, void *param)
{
    SDL_Event event;
    SDL_UserEvent userevent;

    /* In this example, our callback pushes an SDL_USEREVENT event
    into the queue, and causes our callback to be called again at the
    same interval: */

    userevent.type = SDL_USEREVENT;
    userevent.code = 0;
    userevent.data1 = NULL;
    userevent.data2 = NULL;

    event.type = SDL_USEREVENT;
    event.user = userevent;

    SDL_PushEvent(&event);
    return(interval);
}


int main(int argc, char ** argv)
{
    net_init("10.23.14.12",5001,5000);
    int data = 101;
    SDL_Thread* threadID = SDL_CreateThread(threadReceiver, "Receiver", (void*)data);
int quit= false;
int flag=0;
int collision = 0;
SDLS_init("test");
        Uint32 delay = 60;
        SDL_TimerID my_timer = SDL_AddTimer(delay,my_callbackfunc,NULL);

        fn_conf_image ();
        fn_charger_image();
        fn_decoupage();


while(!quit)
    {
        SDL_Event event;

        SDL_WaitEvent(&event);

        switch (event.type)
        {
        case SDL_QUIT :
            quit = true;
            break;

        case SDL_USEREVENT :

            if(event.user.code==1)
            {
                char* sz= (char*)event.user.data1;
                switch(sz[0])
                {
                case 'L' :
                    fn_win();
                    break;
                }
            }
            if(event.user.code==0)
            {

             SDLS_eraseWithBackgroundColor(255,255,255);
                fn_affiche_bonhomme(flag);
                collision=fn_haie();
                collision=fn_plafond();
                if (collision == 1)
                {
                    fn_collision();
                    SDL_RemoveTimer( my_timer);
                }



             break;
        case SDL_KEYDOWN : case SDL_KEYUP:
                if(event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_UP &&  event.key.keysym.sym != SDLK_DOWN )
                {
                    flag=1; //SAUT
                }

             if(event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_DOWN &&  event.key.keysym.sym != SDLK_UP)
                {
                    flag=2; //ACCROUPI
                }

            if(event.type == SDL_KEYUP && event.key.keysym.sym == SDLK_UP && event.key.keysym.sym != SDLK_DOWN )
                {
                    flag=0; //MARCHE
                }
            if(event.type == SDL_KEYUP && event.key.keysym.sym == SDLK_DOWN && event.key.keysym.sym != SDLK_UP)
                {
                    flag=0; //MARCHE
                }


            }
        }







        SDLS_displayAll();
    }
SDL_RemoveTimer( my_timer);
SDLS_cleanup();
    return 0;
}

