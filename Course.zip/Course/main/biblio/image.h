#include "..\biblio\SDLS.h"


//Fonction pour recuperer les configuration des images
void fn_conf_image ();
//Fonction pour charger les images
void fn_charger_image();
//Fonction pour decoup�es les images
void fn_decoupage();
//Fonction pour afficher le bonhomme != position
void fn_affiche_bonhomme(int );
//Fonction du d�placement de la haie
int fn_haie();
//Fonction du d�placement du plafond
int fn_plafond();
//Fonction de collision avec obstacle
void fn_loose();
//Fonction WINNER
void fn_win();

//Structure info images
struct st_image
{
    char nom[50];
    int Largeur;
    int Hauteur;
    int Nb_image;
    SDL_Rect *Decoup;
    SDL_Texture * texture;
};


