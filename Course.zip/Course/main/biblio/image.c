#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>
#include "..\biblio\SDLS.h"
#include "..\biblio\image.h"
#include "..\biblio\net.h"
#define Pas 13
#define Ecart 1600
#define Depassement -100
//
struct st_image marche,accroupi,saut,haie,plafond,loose,win;
//Positionnement du bonhomme en marche
SDL_Rect gDestBonhomme;
//Compteur pour le mouvement
int cpt1=0;
int cpt2=0;
int cpt3=0;
//
int Bute=0;
//Position de la haie
SDL_Rect gDestHaie = {1250,420,140,100};
SDL_Rect gDestHaie2 = {2050,420,140,100};

int indexHaie = 0;
//Position plafond
SDL_Rect gDestPlafond  = {1650,245,140,100};
SDL_Rect gDestPlafond2  = {2450,245,140,100};

int indexPlafond = 0;
//Position message centre
SDL_Rect gDestCentre = {-300,-200,1920,1080};

void fn_conf_image ()
{
    FILE* fichier = NULL;
    fichier = fopen("conf_image.txt","r");


    if(fichier == NULL)
    {
        printf("Fichier introuvable\n");
    }
    else
    {
        fscanf(fichier, "%s %d %d %d" ,marche.nom,&marche.Largeur,&marche.Hauteur,&marche.Nb_image);
        fscanf(fichier, "%s %d %d %d" ,accroupi.nom,&accroupi.Largeur,&accroupi.Hauteur,&accroupi.Nb_image);
        fscanf(fichier, "%s %d %d %d" ,saut.nom,&saut.Largeur,&saut.Hauteur,&saut.Nb_image);
        fscanf(fichier, "%s %d %d %d" ,haie.nom,&haie.Largeur,&haie.Hauteur,&haie.Nb_image);
        fscanf(fichier, "%s %d %d %d" ,plafond.nom,&plafond.Largeur,&plafond.Hauteur,&plafond.Nb_image);
        fscanf(fichier, "%s %d %d %d" ,loose.nom,&loose.Largeur,&loose.Hauteur,&loose.Nb_image);
        fscanf(fichier, "%s %d %d %d" ,win.nom,&win.Largeur,&win.Hauteur,&win.Nb_image);
    }

}

void fn_charger_image()
{
    //Chargement image marche
char * nommarche = malloc(strlen("images//") + strlen(marche.nom) + 1);
strcpy(nommarche,"images//");
strcat(nommarche,marche.nom);
    //Chargement image accroupi
char * nomaccroupi = malloc(strlen("images//") + strlen(accroupi.nom) + 1);
strcpy(nomaccroupi,"images//");
strcat(nomaccroupi,accroupi.nom);
    //Chargement image saut
char * nomsaut = malloc(strlen("images//") + strlen(saut.nom) + 1);
strcpy(nomsaut,"images//");
strcat(nomsaut,saut.nom);
    //Chargement image haie (boite explosive)
char * nomhaie = malloc(strlen("images//") + strlen(haie.nom) + 1);
strcpy(nomhaie,"images//");
strcat(nomhaie,haie.nom);
    //Chargement image plafond (aigle)
char * nomplafond = malloc(strlen("images//") + strlen(plafond.nom) + 1);
strcpy(nomplafond,"images//");
strcat(nomplafond,plafond.nom);
    //Chargement image LOOSER
char * nomloose = malloc(strlen("images//") + strlen(loose.nom) + 1);
strcpy(nomloose,"images//");
strcat(nomloose,loose.nom);
    //Chargement image WINNEr
char * nomwin = malloc(strlen("images//") + strlen(win.nom) + 1);
strcpy(nomwin,"images//");
strcat(nomwin,win.nom);



marche.texture=SDLS_loadImage(nommarche);
accroupi.texture=SDLS_loadImage(nomaccroupi);
saut.texture =SDLS_loadImage(nomsaut);
haie.texture=SDLS_loadImage(nomhaie);
plafond.texture=SDLS_loadImage(nomplafond);
loose.texture=SDLS_loadImage(nomloose);
win.texture=SDLS_loadImage(nomwin);
}

void fn_decoupage()
{
    //Decoupe image marche
    marche.Decoup= malloc(marche.Nb_image*sizeof(SDL_Rect));
    for (int i=0;i<=5;i++)
    {
        marche.Decoup[i].x=i*marche.Largeur;
        marche.Decoup[i].y=0;
        marche.Decoup[i].w=marche.Largeur;
        marche.Decoup[i].h=marche.Hauteur;
    }
    //Decoupe image accroupi
    accroupi.Decoup= malloc(accroupi.Nb_image*sizeof(SDL_Rect));
        accroupi.Decoup[0].x=0;
        accroupi.Decoup[0].y=0;
        accroupi.Decoup[0].w=accroupi.Largeur;
        accroupi.Decoup[0].h=accroupi.Hauteur;
    //Decoupe image saut
     saut.Decoup= malloc(saut.Nb_image*sizeof(SDL_Rect));
        saut.Decoup[0].x=0;
        saut.Decoup[0].y=0;
        saut.Decoup[0].w=saut.Largeur;
        saut.Decoup[0].h=saut.Hauteur;
    //Decoupe image haie (boite explosive)
    haie.Decoup= malloc(haie.Nb_image*sizeof(SDL_Rect));
        haie.Decoup[0].x=0;
        haie.Decoup[0].y=0;
        haie.Decoup[0].w=haie.Largeur;
        haie.Decoup[0].h=haie.Hauteur;
    //Decoupe image plafond (aigle)
    plafond.Decoup= malloc(plafond.Nb_image*sizeof(SDL_Rect));
        plafond.Decoup[0].x=0;
        plafond.Decoup[0].y=0;
        plafond.Decoup[0].w=plafond.Largeur;
        plafond.Decoup[0].h=plafond.Hauteur;
    //Decoupe image LOOSER
    loose.Decoup= malloc(loose.Nb_image*sizeof(SDL_Rect));
        loose.Decoup[0].x=0;
        loose.Decoup[0].y=0;
        loose.Decoup[0].w=loose.Largeur;
        loose.Decoup[0].h=loose.Hauteur;
        //Decoupe image WINNER
    win.Decoup= malloc(loose.Nb_image*sizeof(SDL_Rect));
        win.Decoup[0].x=0;
        win.Decoup[0].y=0;
        win.Decoup[0].w=win.Largeur;
        win.Decoup[0].h=win.Hauteur;
}

void fn_affiche_bonhomme(int flag)
{
    int flag1= flag;

    if(flag==0)  //MARCHE
    {
        cpt1=cpt1+1;
        if (cpt1==6)
            cpt1=0;
        gDestBonhomme = SDLS_drawFillRect(70,300,96,225);
        SDLS_copyTextureEx(marche.texture,marche.Decoup[cpt1],gDestBonhomme);
    }
    else if (flag==1)   //SAUT
    {
            gDestBonhomme = SDLS_drawFillRect(70,190,69,178);
            SDLS_copyTextureEx(saut.texture,saut.Decoup[0],gDestBonhomme);
    }
    else if(flag==2)    //ACCROUPI
    {
            gDestBonhomme = SDLS_drawFillRect(70,420,92,100);
            SDLS_copyTextureEx(accroupi.texture,accroupi.Decoup[0],gDestBonhomme);
    }

}

int fn_haie()
{

            if (SDL_HasIntersection(&gDestBonhomme,&gDestHaie))
           {
               net_send("L");
                Bute =1;
               return 1;

           }
           else  if (SDL_HasIntersection(&gDestBonhomme,&gDestHaie2))
           {
               net_send("L");
                Bute =1;
               return 1;

           }
           else if  (Bute ==0)
            {
            gDestHaie.x=gDestHaie.x-Pas;
            gDestHaie2.x=gDestHaie2.x-Pas;

            SDLS_copyTextureEx(haie.texture,haie.Decoup[0],gDestHaie);
            SDLS_copyTextureEx(haie.texture,haie.Decoup[0],gDestHaie2);

             if (gDestHaie.x <=  Depassement)
            {
                    gDestHaie.x= Ecart;
            }
            if (gDestHaie2.x <=  Depassement)
            {
                    gDestHaie2.x= Ecart;
            }

            }


}

int fn_plafond()
{

           if (SDL_HasIntersection(&gDestBonhomme,&gDestPlafond))
           {
               net_send("L");
                Bute=1;
               return 1;

           }
           else if (SDL_HasIntersection(&gDestBonhomme,&gDestPlafond2))
           {
               net_send("L");
               Bute=1;
               return 1;

           }
           else if  (Bute ==0)
            {
            gDestPlafond.x=gDestPlafond.x-Pas;
            gDestPlafond2.x=gDestPlafond2.x-Pas;

            SDLS_copyTextureEx(plafond.texture,plafond.Decoup[0],gDestPlafond);
            SDLS_copyTextureEx(plafond.texture,plafond.Decoup[0],gDestPlafond2);
            if (gDestPlafond.x <= Depassement)
            {
                gDestPlafond.x=Ecart;
            }
            if (gDestPlafond2.x <= Depassement)
            {
                gDestPlafond2.x=Ecart;
            }
            }

}


void fn_loose()
{
            SDLS_eraseWithBackgroundColor(255,255,255);
            SDLS_copyTextureEx(loose.texture,loose.Decoup[0],gDestCentre);
}

void fn_win()
{
            SDLS_eraseWithBackgroundColor(255,255,255);
            SDLS_copyTextureEx(win.texture,win.Decoup[0],gDestCentre);
}

